# Lira’s Joyería

Página web de Lira’s Joyería: oro 18k, relojes y reparaciones. El Rosal (Caracas) y La Guaira, Venezuela.

Instagram: [@liras_joyeria](https://www.instagram.com/liras_joyeria/)

Es una página estática de un solo archivo (`index.html`) con todas las fotos incluidas.

## Publicarla con GitHub Pages
1. En el repositorio, entra a **Settings → Pages**.
2. En **Source** elige **Deploy from a branch**, la rama `main` y la carpeta `/ (root)`.
3. Guarda. En uno o dos minutos la página queda en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPOSITORIO/`.
